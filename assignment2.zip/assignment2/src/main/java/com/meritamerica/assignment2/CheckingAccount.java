package com.meritamerica.assignment2;


public class CheckingAccount extends BankAccount {

	public CheckingAccount(double balance) {
		super(balance);
	}

}