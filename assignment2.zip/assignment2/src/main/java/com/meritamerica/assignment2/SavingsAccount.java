package com.meritamerica.assignment2;



public class SavingsAccount extends BankAccount {

	public SavingsAccount(double balance) {
		super(balance);
	}


}